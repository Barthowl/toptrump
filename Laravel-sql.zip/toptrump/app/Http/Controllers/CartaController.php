<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Carta;

class CartaController extends Controller
{
// get
    function index(){ // select all
    return response()->json(Carta::all(),200);
        
    }
// post
    function store(Request $request){ // insert into
        try {
        $objeto = Carta::create($request->all());
        return response()->json(["id" => $objeto->id],200);
        } catch (\Exception $e) {
        return response()->json(["id"=>0],200);
        }
    }

// get
    function show($id){ // select one
        $carta = Carta::find($id);
        return response()->json(["carta" => $carta],200);
    }

// put
    function update(Request $request, $id){ // update
        try {
        $objeto = Carta::find($id);
        $resultado = $objeto->update($request->all());
        return response()->json(["resultado" => $resultado],200);
        } catch (\Exception $e) {
        return response()->json(["resultado"=>false],200);
        }

    }

// delete
    function destroy($id){ // delete
    try {
        $objeto = Carta::find($id);
        if($objeto != null){
        $resultado = $objeto->delete();
        return response()->json(["resultado" => $resultado],200);
        }
        } catch (\Exception $e){
        }
        return response()->json(["resultado" => false],200);
    }
}
