<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Pregunta;

class PreguntaController extends Controller
{
// get
    function index(){ // select all
    return response()->json(Pregunta::all(),200);
        
    }
// post
    function store(Request $request){ // insert into
        try {
        $objeto = Pregunta::create($request->all());
        return response()->json(["id" => $objeto->id],200);
        } catch (\Exception $e) {
        return response()->json(["id"=>0],200);
        }
    }

// get
    function show($id){ // select one
        $pregunta = Pregunta::find($id);
        return response()->json(["Pregunta" => $pregunta],200);
    }

// put
    function update(Request $request, $id){ // update
        try {
        $objeto = Pregunta::find($id);
        $resultado = $objeto->update($request->all());
        return response()->json(["resultado" => $resultado],200);
        } catch (\Exception $e) {
        return response()->json(["resultado"=>false],200);
        }

    }

// delete
    function destroy($id){ // delete
    try {
        $objeto = Pregunta::find($id);
        if($objeto != null){
        $resultado = $objeto->delete();
        return response()->json(["resultado" => $resultado],200);
        }
        } catch (\Exception $e){
        }
        return response()->json(["resultado" => false],200);
    }
}
