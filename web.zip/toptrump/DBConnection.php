<?php

Class DBConnection{
    protected $_config;
    public $dbc;
    public $error = '';
    
    /*
     *   Función que devuelve una instancia de conexión a la BDD
     *   @ param array Contiene los settings de conexión 
     */
    
    public function __construct(array $settings){
        // recoge los datos de settings
        $this->_config = $settings;
        $this-> getDBConnection();
    }
    
    public function __destruct(){
        $this->dbc = null;
    }
    
    public function getDBConnection(){
        if($this->dbc == null){
             $dsn="".$this->_config['driver'].":host=".$this->_config['host'].";dbname=".$this->_config['dbname'].";charset=utf8mb4";
            try{
                $options = array(
                     // 1.mantener conexión abierta, 2.coger las excepciones del pdo
                    PDO::ATTR_PERSISTENT => true,
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
                );
            
                $this->dbc = new PDO($dsn,$this->_config['username'],$this->_config['password'],$options);  
            
            } catch (PDOException $e){
            $this->error = $e ->getMessage();
            
            } return $this->error;
        }
    }
    
    public function getQuery($sql){
    // ejecutar consultas select
    try{
    $resultset = $this->dbc->query($sql);
    $resultset->setFetchMode(PDO::FETCH_ASSOC);
    } catch(PDOException $e){
        echo $e->getMessage();
    }
    return $resultset;
        
    }
    
    public function runQuery($sql){
    // ejecutar consultas delete, insert , etc (devuelve el nº de filas afectadas)
        $cont = 0;
        try{
            $cont = $this->dbc->exec($sql);
            
        } catch(PDOException $e){
            echo $e->getMessage();
        }
        return $cont;
        
    }
}


?>