<?php
require_once("settingsDB.php");
require_once("DBConnection.php");
require_once("cartas.php");
require_once("serial.php");	

$dir = 'images/';

if(isset($_POST["submit"])){ 
	$_POST['score_pic'] = $_POST['nombre']."-".serial(5)."-".$_FILES['score_pic']['name'];
	$nombre = $dir . basename($_POST['score_pic']);
	$foto = $_POST['score_pic'];

	if (move_uploaded_file($_FILES['score_pic']['tmp_name'],$nombre)){
	  } else {}
	  
	  if($_FILES['score_pic']['name'] == null){
		$_POST['score_pic'] = "null";
	  }
	
	$cartas = new cartas($_POST);

	$dbc = new DBConnection($dbsettings); // el array de settingsDB.php
    
    if($dbc){
	  $myfields = $cartas->getFields();
      $name = $_POST['nombre'];
	  $descripcion = $_POST['descripcion'];
	  
	  $sql1 = "select * from carta where nombre =".$myfields['nombre'].";";
	  $rs = $dbc->getQuery($sql1);
	  if($rs->rowCount() == 0){
			  $sql2 = "insert into carta values (".implode(",",$cartas->getFields()).");";
			  $rows = $dbc->runQuery($sql2);
			  $sql3 = "select * from carta where url = '".$foto."';";
			  echo $sql3;
			  $rs2 = $dbc->getQuery($sql3);

			  if($rs2->rowCount() != 0){
				foreach($rs2 as $row){
					header("Location: pregunta.php?id=".$row['id']);
				}
			  }
	  }
		
	} 
}

?>



<!DOCTYPE html>
<!--
	Awesome Responsive Template
	templatestock.co
-->
<html>
<head>
	<title>TopTrump</title>
    <meta name="description" content="🃏¡Crea tus cartas de animales!">
    <link id="favicon" rel="icon" href="https://i.imgur.com/0EVXchX.png" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

	<!-- Goggle Font -->
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">

	<!-- Font Css -->
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">

	<!-- Custom CSS -->
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<!-- Animation Css -->
	<link rel="stylesheet" href="css/animate.css">

	<!-- Script js -->
	<script src="myjs.js"></script>


</head>
<body>




<!-- Cartas -->
<div class="call" id="Cartas">
	<div class="container">
    <nav class="navbar navbar-default">
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse top-right-menu-ul bounceInRight wow" id="bs-example-navbar-collapse-1" data-wow-duration="4s">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php">📔 Menú</a></li>
    </div><!-- End navbar-collapse -->
  </div><!-- End container -->
</nav>
		<div class="row">
			<div class="col-md-12">
				<div class="main_heading">
					<h1>🃏 Crear Cartas</h1>
					<div  class="text-center"><span class="underline"></span></div>
				</div>
			</div><!-- End col-md-12 -->
		</div><!-- End row -->

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="signup"  enctype="multipart/form-data">

		<div class="inputs">

			<img src="images/carta.png" id="img" height="120px"></br>

			<input type="hidden" name="MAX_FILE_SIZE" value="9999999" />
			<input type="file" onchange="readURL(this);" name="score_pic" id="score_pic"  required /></br>

            <input type="text" placeholder="Nombre animal" id="nombre" name="nombre"  required />
			<br/><br/>
            <textarea form="signup" placeholder="Descripción del animal"  id="descripcion" name="descripcion" required></textarea>
            
            <button id="submit" name="submit">Enviar</button>
        
        </div>

    </form>
		</div><!-- End col-md-12-->

	</div><!-- End container -->	
</div>

<!-- End Cartas -->



<script type="text/javascript" src="js/jquery-main.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script src="js/wow.min.js"></script>

<script>
	new WOW().init();
</script>

</body>
</html>