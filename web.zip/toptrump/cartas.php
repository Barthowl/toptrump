<?php
// definición clase
class cartas {
    // el mismo nombre que hemos usado en los atributos name del form
    protected $score_pic;
    protected $nombre;
    protected $descripcion;
    public function __construct($data){
        
        $this->nombre = $data['nombre'];
        $this->descripcion = $data['descripcion'];
        $this->score_pic = $data['score_pic'];
    }
    
    public function getNombre(){
        return $this->nombre;
    }
    
    public function getDescripcion(){
        return $this->descripcion;
    }

    public function getscore_pic(){
        return $this->score_pic;
    } 
    
    public function getFields(){
     //$fields = array();
     $fields[]="NULL"; // preparar getfields para cuando tengamos 1 clave primaria.
     foreach($this as $field => $value){
         $fields[$field]= "'".$value."'";
     }
     return $fields;
    }
    
}

?>