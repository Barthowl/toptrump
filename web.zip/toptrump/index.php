<!DOCTYPE html>
<!--
	Awesome Responsive Template
	templatestock.co
-->
<html>
<head>
	<title>TopTrump</title>
    <meta name="description" content="🃏¡Crea tus cartas de animales!">
    <link id="favicon" rel="icon" href="https://i.imgur.com/0EVXchX.png" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

	<!-- Goggle Font -->
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">

	<!-- Font Css -->
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">

	<!-- Custom CSS -->
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<!-- Animation Css -->
	<link rel="stylesheet" href="css/animate.css">

	<!-- Script js -->
	<script src="myjs.js"></script>


</head>
<body>
<!-- Header -->
<div class="header-div">

<nav class="navbar navbar-default">
  <div class="container">
    <!-- Brand and toggle get grouped for better mobile display -->
    <div class="navbar-header logo-div bounceInLeft wow" data-wow-duration="2s">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1" aria-expanded="false">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>

    </div>
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse top-right-menu-ul bounceInRight wow" id="bs-example-navbar-collapse-1" data-wow-duration="4s">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="carta.php">🃏 Crear Cartas</a></li>
    </div><!-- End navbar-collapse -->
  </div><!-- End container -->
</nav>

<div class="container wow bounceInDown" data-wow-duration="5s">
	<div class="row">
		<div class="col-md-offset-2 col-md-8 text-center slide-text">
			<h1 class="shadow">🦥 TopTrump</h1>
			<p class="shadow2">¡Nuevo juego de cartas con preguntas sobre animales! ¿Crees saber todo lo relacionado con los animales? no dudes en probarlo e intentar conseguir la puntuación más alta!</p>
		</div><!-- End col-md-8-->
		<div class="col-md-offset-2"></div><!-- End col-md-offset-2 -->
	</div><!-- End Row -->
</div><!-- End Contanier -->

</div><!-- End header-div -->

<!-- Feature -->

<div class="container" id="features">
	<div class="row">
		<div class="col-md-12">
			<div class="main_heading">
				<h1>Características</h1>
				<div  class="text-center"><span class="underline"></span></div>
			</div>
		</div><!-- End col-md-12 -->
	</div><!-- End row -->

	<div class="row">
		<div class="col-md-3 col-sm-6">
			<div class="features-div">
				<i class="fa fa-paw"></i>
			   <h4>Aprende jugando</h4>
			   <p>¡Aprende curiosidades de los animales mientras te diviertes jugando!</p>
			</div>
		</div><!-- End col-md-3-->
		<div class="col-md-3 col-sm-6">
			<div class="features-div">
			   <i class="fa fa-key"></i>
			   <h4>Administra</h4>
			   <p>¡Crea usuarios y nuevas cartas! el contenido ahora es infinito</p>
			</div>
		</div><!-- End col-md-3-->
		<div class="col-md-3 col-sm-6">
			<div class="features-div">
			   <i class="fa fa-star"></i>
			   <h4>Puntuación</h4>
			   <p>¡Mira tu puntuación y consigue más acertando todas las preguntas!</p>
			</div>			
		</div><!-- End col-md-3-->
		<div class="col-md-3 col-sm-6">
			<div class="features-div">
			<i class="fa fa-envelope"></i>
			   <h4>Comparte</h4>
			   <p>¡Puedes compartir tu puntuación contigo mismo e intentar superarte!</p>
			</div>			
		</div><!-- End col-md-3-->
	</div><!-- End row -->
</div><!-- End Container -->


<!-- About -->
<div class="container" id="About">
	<div class="row">
		<div class="col-md-12">
			<div class="main_heading">
				<h1>Sobre nosotros</h1>
				<div  class="text-center"><span class="underline"></span></div>
			</div>
		</div><!-- End col-md-12 -->
	</div><!-- End row -->


	<div class="row">
		<div class="col-md-6 about-us-box wow fadeInUp animated">
		    <div class="about-us-photo">
		    	<img class="img" src="images/1.png" alt="">
		    	<div class="about-us-role">Web Dev</div>
		    </div>
		    <h3>Manuel Morales</h3>
		    <p>Hago cosas pero no muchas.</p>
		</div>

		<div class="col-md-6 about-us-box wow fadeInUp animated">
		    <div class="about-us-photo">
		    	<img class="img" src="images/2.png" alt="">
		    	<div class="about-us-role">App Dev</div>
		    </div>
		    <h3>Jose Santiago</h3>
		    <p>Contento con la vida pero no mucho.</p>
		</div>
	</div><!-- End row -->

</div><!-- End container -->	
<!-- End About -->

<script type="text/javascript" src="js/jquery-main.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script src="js/wow.min.js"></script>

<script>
	new WOW().init();
</script>

  <!-- Site footer -->
  <footer class="site-footer">
<div class="container">
        <div class="row">
          <div class="col-md-12 col-sm-6 col-xs-12">
            <p class="copyright-text">Copyright &copy; 2021 Todos los derechos reservados por 
         <a href="#">TopTump</a>.
              </p>
          </div>
        </div>
      </div>
</footer>

</body>
</html>