<?php
require_once("settingsDB.php");
require_once("DBConnection.php");
require_once("preguntas.php");

if($_GET['id'] == null){
	 header("Location: index.php");
  }


if(isset($_POST["submit"])){ 
	$preguntas = new preguntas($_POST);
	$preguntas2 = new preguntas($_POST);
	$preguntas3 = new preguntas($_POST);
	$preguntas4 = new preguntas($_POST);

	$dbc = new DBConnection($dbsettings); // el array de settingsDB.php
    
    if($dbc){
	$sqlid = "select id from carta order by id desc limit 1;";
	$rows = $dbc->getQuery($sqlid);
	if($rows->rowCount() != 0){
		foreach($rows as $row){
			$id = $row['id'];

			$pregun1  = "Tamaño del animal(Metros):";
			$pregun2 = "Peso del animal(Kilogramos):";
			$pregun3 = "Velocidad del animal(Kilometros/hora):";
			$pregun4 = "Evasion del animal(Evaluar del 0 al 10):";

			$respuesta1 = $_POST['respuesta'];
			$respuesta2 = $_POST['respuesta2'];
			$respuesta3 = $_POST['respuesta3'];
			$respuesta4 = $_POST['respuesta4'];

			$preguntas->setPregunta($pregun1);
			$preguntas->setId($id);

			$preguntas2->setPregunta($pregun2);
			$preguntas2->setId($id);
			$preguntas2->setRespuesta($respuesta2);

			$preguntas3->setPregunta($pregun3);
			$preguntas3->setId($id);
			$preguntas3->setRespuesta($respuesta3);

			$preguntas4->setPregunta($pregun4);
			$preguntas4->setId($id);
			$preguntas4->setRespuesta($respuesta4);

			$sql1 = "insert into pregunta values (".implode(",",$preguntas->getFields()).");";
			$sql2 = "insert into pregunta values (".implode(",",$preguntas2->getFields()).");";
			$sql3 = "insert into pregunta values (".implode(",",$preguntas3->getFields()).");";
			$sql4 = "insert into pregunta values (".implode(",",$preguntas4->getFields()).");";
			
			$rows1 = $dbc->runQuery($sql1);
			$rows2 = $dbc->runQuery($sql2);
			$rows3 = $dbc->runQuery($sql3);
			$rows4 = $dbc->runQuery($sql4);

		}
	  }



	}


}

?>



<!DOCTYPE html>
<!--
	Awesome Responsive Template
	templatestock.co
-->
<html>
<head>
	<title>TopTrump</title>
    <meta name="description" content="🃏¡Crea tus cartas de animales!">
    <link id="favicon" rel="icon" href="https://i.imgur.com/0EVXchX.png" type="image/x-icon">
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0">

	<!-- Bootstrap CSS -->
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">

	<!-- Goggle Font -->
	<link rel="stylesheet" type="text/css" href="http://fonts.googleapis.com/css?family=Roboto:400,100,300,500">

	<!-- Font Css -->
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">

	<!-- Custom CSS -->
	<link rel="stylesheet" type="text/css" href="css/style.css">

	<!-- Animation Css -->
	<link rel="stylesheet" href="css/animate.css">

	<!-- Script js -->
	<script src="myjs.js"></script>


</head>
<body>




<!-- Preguntas -->
<div class="call" id="Cartas">
	<div class="container">
    <nav class="navbar navbar-default">
    <!-- Collect the nav links, forms, and other content for toggling -->
    <div class="collapse navbar-collapse top-right-menu-ul bounceInRight wow" id="bs-example-navbar-collapse-1" data-wow-duration="4s">
      <ul class="nav navbar-nav navbar-right">
        <li><a href="index.php">📔 Menú</a></li>
        <li><a href="carta.php">🃏 Crear Cartas</a></li>
    </div><!-- End navbar-collapse -->
    </nav>
    </div><!-- End container -->
		<div class="row">
			<div class="col-md-12">
				<div class="main_heading">
                    <h1>❓ Crear Preguntas</h1>
					<div  class="text-center"><span class="underline"></span></div>
				</div>
			</div><!-- End col-md-12 -->
		</div><!-- End row -->

    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" id="signup2"  enctype="multipart/form-data">

		<div class="inputs">

		<label for="pregunta" name="pregunta">Tamaño del animal(Metros):</label><input type="text" id="respuesta" name="respuesta"  required />
		<br/><br/>
		<label for="pregunta2" name="pregunta2">Peso del animal(Kilogramos):</label><input type="text" id="respuesta2" name="respuesta2"  required />
		<br/><br/>
		<label for="pregunta3" name="pregunta3">Velocidad del animal(Kilometros/hora):</label><input type="text" id="respuesta3" name="respuesta3"  required />
		<br/><br/>
		<label for="pregunta4" name="pregunta4">Evasion del animal(Evaluar del 0 al 10):</label><input type="number" id="respuesta4" name="respuesta4"  min="0" max="10" required />

        <button id="submit" name="submit">Enviar</button>
        
        </div>

    </form>
		</div><!-- End col-md-12-->

	</div><!-- End container -->	
</div>

<!-- End Preguntas -->

<script type="text/javascript" src="js/jquery-main.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script src="js/wow.min.js"></script>

<script>
	new WOW().init();
</script>

</body>
</html>