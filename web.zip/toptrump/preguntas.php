<?php
// definición clase
class preguntas {
    // el mismo nombre que hemos usado en los atributos name del form
    protected $idcarta;
    protected $pregunta;
    protected $respuesta;


    public function __construct($data){
        $this->idcarta = $data['idcarta'];
        $this->pregunta = $data['pregunta'];
        $this->respuesta = $data['respuesta'];
    }

    public function getIdcarta(){
        return $this->idcarta;
    }

    public function setId($idcarta){
        $this->idcarta = $idcarta;
    }
    
    public function getPregunta(){
        return $this->pregunta;
    }

    public function setPregunta($pregunta){
        $this->pregunta = $pregunta;
    }

    public function getRespuesta(){
        return $this->respuesta;
    }

    public function setRespuesta($respuesta){
        $this->respuesta = $respuesta;
    }
    
    
    
    public function getFields(){
     //$fields = array();
     $fields[]="NULL"; // preparar getfields para cuando tengamos 1 clave primaria.
     foreach($this as $field => $value){
         $fields[$field]= "'".$value."'";
     }
     return $fields;
    }
    
}

?>