<?php
function serial($n){
    // cadena que voy a usar
    $resultado = "";
    $cadena = "7rTnr4PKATAD2UCxugAqPH5FBRWugqY3fdJBxv7nYJ6eFBqaSpjwUQvkkxAdTyYad9Tt8WFxKZWdmmbXkHUnxLETgki3ekNQEnYWTGVtawAhLMJ5efxEJvRi5XuvxWUgcCSzdCvRf2MQegnmuimVEdNzg3myRA2wNNiQAu98Gf8mRfynhCxL8qEYkMPJ4jquThxk3CGzE5YdW6S8H28eXbiNSDMXjBwzMnabk8eKyidWKBQGTqXchHXRmD45BApL2H2qJKjiukpLuYGZerTdiNdpkQYbGhQXN6VFQN2Kt9aE";
    // longitud de la cadena
    $total = strlen($cadena);
    // hacemos un bucle tantos caracteres quiera en $n
    for($i = 0 ; $i < $n; $i++){
    // cogemos 1 caracter aleatorio entre 0 y la longitud de la cadena-1 $n veces
    $aleatorio = mt_rand(0,$total-1);
    // cogemos 1 caracter de la posición $aleatorio de la $cadena $n veces
    $final = substr($cadena,$aleatorio,1);
    // cogemos los caracteres generados $n veces y lo sumamos a $resultado
    $resultado .= $final;
    }
    // lo devolvemos
    return $resultado;
}

?>