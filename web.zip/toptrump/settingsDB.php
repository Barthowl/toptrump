<?php

$dbsettings = array(
    
    'driver'=>'mysql',
    'host'=>'localhost',
    'dbname'=>'toptrump',
    'username'=>'root',
    'password'=>'admin',
    );



?>